<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=bs_test',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];
